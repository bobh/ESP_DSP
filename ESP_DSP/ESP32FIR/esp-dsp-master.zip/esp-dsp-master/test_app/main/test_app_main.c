#include "unity.h"

void app_main()
{
    unity_run_menu();
}
